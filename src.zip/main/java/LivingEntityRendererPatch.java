package shit.zen.patch;

import asm.patchify.annotation.At;
import asm.patchify.annotation.Inject;
import asm.patchify.annotation.Patch;
import asm.patchify.annotation.Slice;
import asm.patchify.annotation.WrapInvoke;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderStateShard;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import shit.zen.ClientBase;
import shit.zen.ZenClient;
import shit.zen.asm.Invocation;
import shit.zen.event.impl.RenderEntityEvent;
import shit.zen.event.impl.RotationAnimationEvent;
import shit.zen.modules.impl.render.ESP;

import java.awt.Color;

@Patch(LivingEntityRenderer.class)
public class LivingEntityRendererPatch {
    /** 当前渲染的实体是否是自己（renderToBuffer 双保险隐藏原版身体用） */
    public static boolean currentRenderingSelf = false;
    /** 原版玩家模型骨骼实际旋转（每帧 setupAnim 结果——真绑定原版骨骼）。
     *  索引 0-5: head/body/leftArm/rightArm/leftLeg/rightLeg，每骨骼 xRot/yRot/zRot */
    public static final float[] SELF_BONE_ROT = new float[18];

    @Inject(
            method = "render",
            desc = "(Lnet/minecraft/world/entity/LivingEntity;FFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V",
            at = @At(At.Type.HEAD)
    )
    public static void onRenderPre(
            LivingEntityRenderer<?, ?> renderer, LivingEntity entity, float yaw, float partialTick,
            PoseStack poseStack, MultiBufferSource bufferSource, int packedLight, CallbackInfo callbackInfo) {
        if (!ZenClient.isReady()) return;
        if (entity == ClientBase.mc.player) {
            shit.zen.modules.impl.render.Freelook freelook = shit.zen.modules.impl.render.Freelook.INSTANCE;
            if (freelook != null && freelook.isEnabled() && freelook.isCameraActive()
                    && freelook.alwaysActive.getValue()) {
                freelook.applyInterpolatedModelRotation(partialTick);
            }
        }
        // YsmModel（纯替换模式）：渲染波奇酱成功 → cancel 原版（彻底无原版衣服）；
        // 关闭或失败 → 恢复原版
        if (entity == ClientBase.mc.player) {
            currentRenderingSelf = true;
            shit.zen.modules.impl.render.YsmModel ym = shit.zen.modules.impl.render.YsmModel.INSTANCE;
            if (ym != null && ym.isEnabled()) {
                // cancel 原版后 setupAnim 不会执行——手动调用原版 setupAnim，
                // 然后读取骨骼实际旋转（真绑定原版骨骼，覆盖所有动画状态）
                if (renderer instanceof net.minecraft.client.renderer.entity.player.PlayerRenderer pr) {
                    net.minecraft.client.model.PlayerModel<?> pm =
                            (net.minecraft.client.model.PlayerModel<?>) pr.getModel();
                    if (entity instanceof net.minecraft.world.entity.player.Player pl) {
                        // Mirror LivingEntityRenderer's model preparation order and arguments.
                        // The first animation argument is the walk phase; the second is speed.
                        float limbSwing = 0.0f;
                        float limbSwingAmount = 0.0f;
                        if (!pl.isPassenger() && pl.isAlive()) {
                            // LivingEntityRenderer passes the walk phase first and
                            // the clamped walk amount second. Swapping them freezes
                            // the phase while walking and leaves the limbs one forward
                            // and one back.
                            limbSwing = pl.walkAnimation.position(partialTick);
                            limbSwingAmount = pl.walkAnimation.speed(partialTick);
                            if (pl.isBaby()) {
                                limbSwing *= 3.0f;
                            }
                            if (limbSwingAmount > 1.0f) {
                                limbSwingAmount = 1.0f;
                            }
                        }
                        pm.attackTime = pl.getAttackAnim(partialTick);
                        pm.crouching = pl.isCrouching();
                        pm.riding = pl.isPassenger();
                        pm.young = pl.isBaby();
                        @SuppressWarnings("rawtypes")
                        net.minecraft.client.model.PlayerModel rawModel = pm;
                        rawModel.prepareMobModel(pl, limbSwing, limbSwingAmount, partialTick);
                        float bodyYawLocal = Mth.rotLerp(partialTick, pl.yBodyRotO, pl.yBodyRot);
                        // YsmModel renders before vanilla LivingEntityRenderer reaches its
                        // rotation wrappers, so dispatch the same animation event here.
                        RotationAnimationEvent rotationEvent = new RotationAnimationEvent(
                                pl.yHeadRot, pl.yHeadRotO, pl.getXRot(), pl.xRotO);
                        ZenClient.getInstance().getEventBus().call(rotationEvent);
                        float renderHeadYaw = Mth.rotLerp(
                                partialTick, rotationEvent.getLastYaw(), rotationEvent.getYaw());
                        float netHeadYaw = renderHeadYaw - bodyYawLocal;
                        float headPitch = Mth.lerp(
                                partialTick, rotationEvent.getLastPitch(), rotationEvent.getPitch());
                        net.minecraft.client.model.PlayerModel<net.minecraft.client.player.AbstractClientPlayer> pmc =
                                (net.minecraft.client.model.PlayerModel<net.minecraft.client.player.AbstractClientPlayer>) pm;
                        pmc.setupAnim((net.minecraft.client.player.AbstractClientPlayer) pl,
                                limbSwing, limbSwingAmount, pl.tickCount + partialTick,
                                netHeadYaw, headPitch);
                    }
                    net.minecraft.client.model.geom.ModelPart[] parts = {
                            pm.head, pm.body, pm.leftArm, pm.rightArm, pm.leftLeg, pm.rightLeg};
                    for (int bi = 0; bi < 6; bi++) {
                        SELF_BONE_ROT[bi * 3] = parts[bi].xRot;
                        SELF_BONE_ROT[bi * 3 + 1] = parts[bi].yRot;
                        SELF_BONE_ROT[bi * 3 + 2] = parts[bi].zRot;
                    }
                }
                if (ym.renderInto(poseStack, bufferSource, partialTick, packedLight)) {
                    callbackInfo.cancel();
                    return;
                }
            }
            // YsmModel 关闭/失败 → 恢复原版模型可见
            if (renderer instanceof net.minecraft.client.renderer.entity.player.PlayerRenderer pr) {
                net.minecraft.client.model.PlayerModel<?> pm =
                        (net.minecraft.client.model.PlayerModel<?>) pr.getModel();
                pm.head.visible = true;
                pm.hat.visible = true;
                pm.body.visible = true;
                pm.rightArm.visible = true;
                pm.leftArm.visible = true;
                pm.rightLeg.visible = true;
                pm.leftLeg.visible = true;
            }
        } else {
            currentRenderingSelf = false;
        }
        RenderEntityEvent.Post pre = new RenderEntityEvent.Post(renderer, entity, poseStack, bufferSource, partialTick, packedLight);
        ZenClient.getInstance().getEventBus().call(pre);
        if (pre.isCancelled()) {
            callbackInfo.cancel();
            return;
        }
    }

    @Inject(
            method = "render",
            desc = "(Lnet/minecraft/world/entity/LivingEntity;FFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V",
            at = @At(At.Type.TAIL)
    )
    public static void onRenderPost(
            LivingEntityRenderer<?, ?> renderer, LivingEntity entity, float yaw, float partialTick,
            PoseStack poseStack, MultiBufferSource bufferSource, int packedLight, CallbackInfo callbackInfo) {
        if (!ZenClient.isReady()) return;
        RenderEntityEvent.Pre post = new RenderEntityEvent.Pre(renderer, entity, poseStack, bufferSource, partialTick, packedLight);
        ZenClient.getInstance().getEventBus().call(post);
    }

    @WrapInvoke(
            method = "render",
            desc = "(Lnet/minecraft/world/entity/LivingEntity;FFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V",
            target = "net/minecraft/util/Mth/rotLerp",
            targetDesc = "(FFF)F",
            slice = @Slice(startIndex = 2, endIndex = 2)
    )
    public static float onRenderHeadYawLerp(
            LivingEntityRenderer<?, ?> renderer, LivingEntity entity, float entityYaw, float partialTick,
            PoseStack poseStack, MultiBufferSource bufferSource, int packedLight,
            Invocation<Object, Float> original) throws Exception {
        float delta = (Float) original.args().get(0);
        float start = (Float) original.args().get(1);
        float end   = (Float) original.args().get(2);
        RotationAnimationEvent event = new RotationAnimationEvent(end, start, 0.0f, 0.0f);
        if (ZenClient.isReady() && entity == ClientBase.mc.player) {
            ZenClient.getInstance().getEventBus().call(event);
        }
        return Mth.rotLerp(delta, event.getLastYaw(), event.getYaw());
    }

    @WrapInvoke(
            method = "render",
            desc = "(Lnet/minecraft/world/entity/LivingEntity;FFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V",
            target = "net/minecraft/util/Mth/lerp",
            targetDesc = "(FFF)F",
            slice = @Slice(startIndex = 1, endIndex = 1)
    )
    public static float onRenderPitchLerp(
            LivingEntityRenderer<?, ?> renderer, LivingEntity entity, float entityYaw, float partialTick,
            PoseStack poseStack, MultiBufferSource bufferSource, int packedLight,
            Invocation<Object, Float> original) throws Exception {
        float delta = (Float) original.args().get(0);
        float start = (Float) original.args().get(1);
        float end   = (Float) original.args().get(2);
        RotationAnimationEvent event = new RotationAnimationEvent(0.0f, 0.0f, end, start);
        if (ZenClient.isReady() && entity == ClientBase.mc.player) {
            ZenClient.getInstance().getEventBus().call(event);
        }
        return Mth.lerp(delta, event.getLastPitch(), event.getPitch());
    }

}
