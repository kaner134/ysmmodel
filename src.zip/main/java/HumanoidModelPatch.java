package shit.zen.patch;

import asm.patchify.annotation.At;
import asm.patchify.annotation.Inject;
import asm.patchify.annotation.Patch;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.PlayerModel;
import shit.zen.modules.impl.render.YsmModel;

/**
 * HumanoidModelPatch —— YsmModel 启用时拦截玩家身体模型渲染（双保险隐藏原版身体）。
 *
 * 仅拦截"自己"的 PlayerModel（LivingEntityRendererPatch.currentRenderingSelf 标志）：
 * - 其他玩家/生物：标志 false → 正常
 * - 盔甲模型（HumanoidArmorModel）：instanceof PlayerModel 为 false → 正常
 * - 第一人称手臂：标志 false → 正常
 */
@Patch(HumanoidModel.class)
public class HumanoidModelPatch {

    @Inject(
            method = "renderToBuffer",
            desc = "(Lcom/mojang/blaze3d/vertex/PoseStack;Lcom/mojang/blaze3d/vertex/VertexConsumer;IIFFFF)V",
            at = @At(At.Type.HEAD)
    )
    public static void onRenderToBuffer(
            HumanoidModel<?> model, PoseStack poseStack, VertexConsumer vertexConsumer,
            int i, int j, float f, float g, float h, float k, CallbackInfo ci) {
        // 只拦截"自己"的玩家身体模型（波奇酱已渲染，原版身体隐藏）
        if (!LivingEntityRendererPatch.currentRenderingSelf) {
            return;
        }
        if (model instanceof PlayerModel
                && YsmModel.INSTANCE != null && YsmModel.INSTANCE.isEnabled()) {
            ci.cancel();
        }
    }
}
