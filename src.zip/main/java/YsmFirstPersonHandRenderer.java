package shit.zen.patch;

import net.minecraftforge.client.event.RenderArmEvent;
import shit.zen.ClientBase;
import shit.zen.ZenClient;
import shit.zen.modules.impl.render.YsmModel;

/** Replaces Forge's vanilla first-person arm draw with the loaded YSM arm mesh. */
public final class YsmFirstPersonHandRenderer {
    private YsmFirstPersonHandRenderer() {
    }

    public static void onRenderArm(RenderArmEvent event) {
        if (!ZenClient.isReady() || ClientBase.mc == null
                || event.getPlayer() != ClientBase.mc.player) {
            return;
        }
        YsmModel model = YsmModel.INSTANCE;
        if (model == null || !model.isEnabled()) {
            return;
        }
        try {
            if (model.renderFirstPersonArm(event.getArm(), event.getPoseStack(),
                    event.getMultiBufferSource(), event.getPackedLight(),
                    ClientBase.mc.getFrameTime())) {
                event.setCanceled(true);
            }
        } catch (Throwable ignored) {
            // A malformed optional arm mesh should fall back to vanilla hands.
        }
    }
}
